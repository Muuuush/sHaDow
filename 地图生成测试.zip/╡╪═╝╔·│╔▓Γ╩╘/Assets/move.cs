using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move : MonoBehaviour
{
    
    private GameObject Core;

    private GameObject[] lightened_road= new GameObject[5];
    private int lightened_road_number = 0;
    bool lightened_flag=true;

    public GameObject Pl_go;
    public Player Pl;
    public Material normal_road;
    public Material light_road;
    public Material center_road;
    public Material monster_road;



    // Start is called before the first frame update


    void lighten()
    {
        Material[] newTmMatArray;
        var map = Core.GetComponent<MapGenerate>().map;
        int[,] dic = new int[,] { { 0, 1 }, { -1, 0 }, { 0, -1 }, { 1, 0 }, { 0, 0 } };
        for (int x = 0; x < lightened_road_number; x++)
        {
            GameObject GamObj = lightened_road[x];
            newTmMatArray = new Material[GamObj.GetComponent<MeshRenderer>().materials.Length];
            //��ȡȫ������
            for (int i1 = 0; i1 < newTmMatArray.Length; i1++)
            {
                newTmMatArray[i1] = normal_road;
            }
            GamObj.GetComponent<MeshRenderer>().materials = newTmMatArray;       //����ͨ���鸳��ģ�Ͳ���
        }
        lightened_road_number = 0;

        for (int x = 0; x < 5; x++)
        {
            int i = Pl.di.x; int j = Pl.di.y;
            if (x == 4 || i + dic[x, 0] >= 0 && i + dic[x, 0] < map.length && j + dic[x, 1] >= 0 && j + dic[x, 1] < map.width && map.maze[i + dic[x, 0], j + dic[x, 1]] != "  ")
            {
                GameObject GamObj = Core.GetComponent<MapGenerate>().maze_vitural[i + dic[x, 0], j + dic[x, 1]];
                lightened_road[lightened_road_number] = GamObj;
                lightened_road_number += 1;
                newTmMatArray = new Material[GamObj.GetComponent<MeshRenderer>().materials.Length];
                //��ȡȫ������
                for (int i1 = 0; i1 < newTmMatArray.Length; i1++)
                {
                    if (x == 4) { newTmMatArray[i1] = center_road; }
                    else
                    {
                        switch (map.maze[i + dic[x, 0], j + dic[x, 1]])
                        {
                            case "��":
                                { newTmMatArray[i1] = monster_road; }
                                break;
                            case "͵":
                                { newTmMatArray[i1] = monster_road; }
                                break;
                            case "å":
                                { newTmMatArray[i1] = monster_road; }
                                break;
                            default:
                                { newTmMatArray[i1] = light_road; }
                                break;
                        }


                    }

                    GamObj.GetComponent<MeshRenderer>().materials = newTmMatArray;//���������鸳��ģ�Ͳ���
                }
            }
        }
    }


    void Start()
    {   
        Core = GameObject.Find("Core");

    }

    // Update is called once per frame


    void Update()
    {
        if (lightened_flag) { lighten(); lightened_flag = false; }
        if (Input.GetMouseButtonDown(0)&& Pl_go.transform.localPosition== new Vector3(Pl.di[0], 0, Pl.di[1]) * Core.GetComponent<MapGenerate>().K)
        {
            var Core_script = Core.GetComponent<MapGenerate>();
            var map = Core.GetComponent<MapGenerate>().map;
            RaycastHit hitInfo;
            Vector2 mousepos = Input.mousePosition;
            Ray ray1 = Camera.main.ScreenPointToRay(mousepos);
            int mask = LayerMask.GetMask("object");
            if(Physics.Raycast(ray1,out hitInfo,1000,mask))
            {
                Transform trans = hitInfo.transform;
                int x1 = (int)(trans.localPosition.x/ Core_script.K);
                int z1 = (int)(trans.localPosition.z/ Core_script.K);

                int[,] dic = new int[,] { { 0, 1 }, { -1, 0 }, { 0, -1 }, { 1, 0 } };
                bool flag=false;
                for (int x=0; x < 4; x++)
                {
                    if (Pl.di.x + dic[x, 0] == x1 && Pl.di.y + dic[x, 1]== z1)
                    { flag=true;
                        break;
                    }
                }
                //Debug.Log(Pl.di.x); Debug.Log(Pl.di.y); Debug.Log(x1); Debug.Log(z1);
                if (map.maze[x1,z1]!= "  " && flag )
                { Pl.di = new Vector2Int(x1, z1);
                  //Pl_go.transform.position = new Vector3(Pl.di[0], 0, Pl.di[1]) * Core_script.K;
                }
                lighten();//����
            }

        }
        Pl_go.transform.localPosition = Vector3.MoveTowards(Pl_go.transform.localPosition, new Vector3(Pl.di[0], 0, Pl.di[1]) * Core.GetComponent<MapGenerate>().K, 25* Time.deltaTime);
    }
}