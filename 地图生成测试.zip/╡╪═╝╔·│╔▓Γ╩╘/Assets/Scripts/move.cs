using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move : MonoBehaviour
{

    private GameObject Core;

    private GameObject[] lightened_road = new GameObject[5];
    private int lightened_road_number = 0;
    bool lightened_flag = true;
    bool turn = true;

    public GameObject Pl_go;
    public Player Pl;
    public Material normal_road;
    public Material light_road;
    public Material center_road;
    public Material monster_road;



    // Start is called before the first frame update


    void lighten()
    {
        Material[] newTmMatArray;
        var map = Core.GetComponent<MapGenerate>().map;
        int[,] dic = new int[,] { { 0, 1 }, { -1, 0 }, { 0, -1 }, { 1, 0 }, { 0, 0 } };
        for (int x = 0; x < lightened_road_number; x++)
        {
            GameObject GamObj = lightened_road[x];
            newTmMatArray = new Material[GamObj.GetComponent<MeshRenderer>().materials.Length];
            //��ȡȫ������
            for (int i1 = 0; i1 < newTmMatArray.Length; i1++)
            {
                newTmMatArray[i1] = normal_road;
            }
            GamObj.GetComponent<MeshRenderer>().materials = newTmMatArray;       //����ͨ���鸳��ģ�Ͳ���
        }
        lightened_road_number = 0;

        for (int x = 0; x < 5; x++)
        {
            int i = Pl.di.x; int j = Pl.di.y;
            if (x == 4 || i + dic[x, 0] >= 0 && i + dic[x, 0] < map.length && j + dic[x, 1] >= 0 && j + dic[x, 1] < map.width && map.maze[i + dic[x, 0], j + dic[x, 1]] != "  ")
            {

                GameObject GamObj = Core.GetComponent<MapGenerate>().maze_vitural[i + dic[x, 0], j + dic[x, 1]];
                lightened_road[lightened_road_number] = GamObj;
                lightened_road_number += 1;
                newTmMatArray = new Material[GamObj.GetComponent<MeshRenderer>().materials.Length];
                //��ȡȫ������
                for (int i1 = 0; i1 < newTmMatArray.Length; i1++)
                {
                    if (x == 4) { newTmMatArray[i1] = center_road; }
                    else
                    {
                        switch (map.maze[i + dic[x, 0], j + dic[x, 1]])
                        {
                            case "��":
                                { newTmMatArray[i1] = monster_road; }
                                break;
                            case "͵":
                                { newTmMatArray[i1] = monster_road; }
                                break;
                            case "å":
                                { newTmMatArray[i1] = monster_road; }
                                break;
                            default:
                                { newTmMatArray[i1] = light_road; }
                                break;
                        }


                    }

                    GamObj.GetComponent<MeshRenderer>().materials = newTmMatArray;//���������鸳��ģ�Ͳ���
                }
            }
        }
    }
    void monster_move()
    {
        var Core_script = Core.GetComponent<MapGenerate>();
        var mos_di = Core_script.monstersLocation;
        var mos_di_1 = Core_script.monstersLocation2;
        int[,] dic = new int[,] { { 0, 1 }, { -1, 0 }, { 0, -1 }, { 1, 0 } };
        var map = Core_script.map;
        List<Vector2Int> choice = new List<Vector2Int>(); ;
        Vector2Int choice_final;

        mos_di_1.Clear();//����б�����
        bool mo_flag;
        for (int x = 0; x < mos_di.Count; x++)
        {
            mo_flag = false;
            int i = mos_di[x][0];
            int j = mos_di[x][1];
            for (int y = 0; y < 4; y++)
            {
                if ((i + dic[y, 0] >= 0 && i + dic[y, 0] < map.length && j + dic[y, 1] >= 0 && j + dic[y, 1] < map.width && map.maze[i + dic[y, 0], j + dic[y, 1]] == "��"))
                {
                    choice.Add(new Vector2Int(i + dic[y, 0], j + dic[y, 1]));
                    mo_flag = true;
                }
            }//ս�������˫������һ���ٽ���
            if (mo_flag)
            {
                choice_final = choice[Random.Range(0, choice.Count)];

                map.maze[choice_final.x, choice_final.y] = map.maze[i, j];
                map.maze[i, j] = "��";
                mos_di_1.Add(new Vector2Int(choice_final.x, choice_final.y));
                choice.Clear();
            }
            else { mos_di_1.Add(new Vector2Int(i, j)); }
        }
    }



    void Start()
    {
        Core = GameObject.Find("Core");

    }

    // Update is called once per frame


    void Update()
    {


        if (lightened_flag) { lighten(); lightened_flag = false; }
        if (Input.GetMouseButtonDown(0) && turn && Pl_go.transform.localPosition == new Vector3(Pl.di[0], 0, Pl.di[1]) * Core.GetComponent<MapGenerate>().K)
        {
            //Debug.Log(0);
            var Core_script = Core.GetComponent<MapGenerate>();
            var map = Core_script.map;
            RaycastHit hitInfo;
            Vector2 mousepos = Input.mousePosition;
            Ray ray1 = Camera.main.ScreenPointToRay(mousepos);
            int mask = LayerMask.GetMask("object");
            if (Physics.Raycast(ray1, out hitInfo, 1000, mask))
            {
                Transform trans = hitInfo.transform;
                int x1 = (int)(trans.localPosition.x / Core_script.K + 0.5f);
                int z1 = (int)(trans.localPosition.z / Core_script.K + 0.5f);

                int[,] dic = new int[,] { { 0, 1 }, { -1, 0 }, { 0, -1 }, { 1, 0 } };
                bool flag = false;
                for (int x = 0; x < 4; x++)
                {
                    if (Pl.di.x + dic[x, 0] == x1 && Pl.di.y + dic[x, 1] == z1)
                    {
                        flag = true;
                        break;
                    }
                }
                if (map.maze[x1, z1] != "  " && flag)//���ƶ�
                {
                    Pl.di = new Vector2Int(x1, z1);
                    //Pl_go.transform.position = new Vector3(Pl.di[0], 0, Pl.di[1]) * Core_script.K;
                    //��ߵü�һ���ȹ����ж�
                    var mos_di = Core_script.monstersLocation;
                    var mos_di_1 = Core_script.monstersLocation2;
                    if (map.maze[x1, z1] == "��" || map.maze[x1, z1] == "͵" || map.maze[x1, z1] == "å")
                    {
                        map.maze[x1, z1] = "��"; for (int x = 0; x < mos_di.Count; x++)
                        {
                            if (mos_di[x] == new Vector2(x1, z1))
                            { Destroy(Core_script.Monsters11[x]); mos_di.RemoveAt(x); mos_di_1.RemoveAt(x); Core_script.Monsters11.RemoveAt(x); }
                        }
                    }

                    //���ƶ�
                    monster_move();

                    // Debug.Log(mos_di.Count); Debug.Log(mos_di_1.Count);
                    //Debug.Log(Pl.di.x); Debug.Log(Pl.di.y); Debug.Log(x1); Debug.Log(z1);

                }


                lighten();//����
                turn = false;//�����ƶ����Կ�ʼ�ж�,���ƶ�ִ�����ٿ�ʼ���ֻ�
            }

        }
        if (Input.GetMouseButtonDown(1) && turn && Pl_go.transform.localPosition == new Vector3(Pl.di[0], 0, Pl.di[1]) * Core.GetComponent<MapGenerate>().K)//�Ҽ���������Ϣ
        {
            monster_move();
            lighten();
            turn = false;
        }


        Pl_go.transform.position = Vector3.MoveTowards(Pl_go.transform.position, new Vector3(Pl.di[0], 0, Pl.di[1]) * Core.GetComponent<MapGenerate>().K, 60 * Time.deltaTime);//����ƶ�


        if (!turn && Pl_go.transform.position == new Vector3(Pl.di[0], 0, Pl.di[1]) * Core.GetComponent<MapGenerate>().K)
        {
            turn = true;
            var Core_script = Core.GetComponent<MapGenerate>();
            var mos_di = Core_script.monstersLocation;
            var mos_di_1 = Core_script.monstersLocation2;
            var map = Core_script.map;


            //Debug.Log(mos_di[0]); Debug.Log(mos_di_1[0]); Debug.Log(Core_script.Monsters11[0].transform.position); Debug.Log(new Vector3(mos_di_1[0].x, 0.2f, mos_di_1[0].y) * Core.GetComponent<MapGenerate>().K);
            for (int x = 0; x < mos_di.Count; x++)
            {
                var m = Core_script.Monsters11[x].transform;
                if (m.position != new Vector3(mos_di_1[x].x, 0.2f, mos_di_1[x].y) * Core.GetComponent<MapGenerate>().K)
                {
                    turn = false;
                    m.position = Vector3.MoveTowards(m.position, new Vector3(mos_di_1[x].x, 0.2f, mos_di_1[x].y) * Core.GetComponent<MapGenerate>().K, 60 * Time.deltaTime);
                }
                else
                {
                    if (m.parent == Core_script.maze_vitural[mos_di[x].x, mos_di[x].y].transform)//���û�иı丽����λ�͸ı�
                    {
                        m.parent = Core_script.maze_vitural[mos_di_1[x].x, mos_di_1[x].y].transform;
                        mos_di[x] = mos_di_1[x];
                        if (mos_di[x] == Pl.di)//�����������ײ��ɾ��
                        { map.maze[Pl.di[0], Pl.di[1]] = "��"; Destroy(m.gameObject); Core_script.Monsters11.RemoveAt(x); mos_di.RemoveAt(x); mos_di_1.RemoveAt(x); }
                    }//�����������ײ��ɾ��

                }
            }
        }
    }
}