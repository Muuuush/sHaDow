using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Tilemaps;
using UnityEngine.UIElements;

public class MapGenerate : MonoBehaviour
{
    public GameObject Pl_go;
    public Player Pl;

    
    public GameObject Foundation;
    public GameObject[] Buildings;
    public GameObject[] Decorations;
    public GameObject[] Roads;
    public GameObject[] Specials;
    public GameObject[] Monsters;

    public GameObject Start_building;
    public GameObject End_building;

    public GameObject[,] maze_vitural;//ʵ����������Ĵ�ŵ�
    public Maze map;


    public float K;
    public int x = 0;
    public Transform B;
    public Transform C;
    public Transform DE;

    private Vector2Int[] steps = { Vector2Int.up, Vector2Int.down, Vector2Int.left, Vector2Int.right };
    private List<Vector2Int> buildingsLocation = new List<Vector2Int>();
    private List<GameObject> buildings = new List<GameObject>();

    public List<GameObject> Monsters11;//���й���Ϸ����Ĵ�ŵ�
    public List<Vector2Int> monstersLocation = new List<Vector2Int>();//����λ�ô�ŵ�
    public List<Vector2Int> monstersLocation2 = new List<Vector2Int>();//����λ�ô�ŵ���µ�

    private List<Vector2Int> roadsLocation = new List<Vector2Int>();
    private List<GameObject> roads = new List<GameObject>();



    private Maze GetMap()
    {
        Maze map = new Maze(0);
        return map;
    }

    /// <summary>
    /// ����װ����
    /// </summary>
    /// <param name="map">��ͼ</param>
    private void GenerateDecorations(Maze map)
    {
        for (int i = 0; i < buildingsLocation.Count; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                Vector2Int loc = buildingsLocation[i] + steps[j];
                // ���Ƿ��ݣ�����������ɫ
                if (-1 < loc[0] && loc[0] < map.length && -1 < loc[1] && loc[1] < map.width && map.maze[loc[0], loc[1]] == "  ")
                {
                    int index = buildingsLocation.IndexOf(loc);
                    buildings[index].GetComponent<MeshFilter>().mesh = buildings[i].GetComponent<MeshFilter>().mesh;
                }
                // ���ǿ�����������װ��
                if (-1 < loc[0] && loc[0] < map.length && -1 < loc[1] && loc[1] < map.width && map.maze[loc[0], loc[1]] != "  " && Random.Range(0, 2) == 1)//������=="��",��Ϊ����·����Ȼ���ߵ��ǿ�����������������ܿ������Ǳ���������
                {
                    var newD = Instantiate(Decorations[Random.Range(0, Decorations.Length)]);
                    newD.transform.SetParent(DE);
                    Vector2 dLoc = buildingsLocation[i] + 0.5f * (Vector2)steps[j];
                    if (steps[j][0] == 0)
                        dLoc[0] += Random.Range(0, 0.4f);
                    else
                        dLoc[1] += Random.Range(0, 0.4f);
                    newD.transform.position = new Vector3(dLoc[0], 0.02f, dLoc[1]) * K;

                    //����װ���﷽��
                    Vector3 DRotation = new Vector3();
                    switch (j)
                    {
                        case 0:
                            DRotation = new Vector3(0, -90, 0);
                            break;
                        case 1:
                            DRotation = new Vector3(0, 90, 0);
                            break;
                        case 2:
                            DRotation = new Vector3(0, 180, 0);

                            break;
                        case 3:
                            DRotation = new Vector3(0, 0, 0);
                            break;
                    }

                    newD.transform.localEulerAngles = DRotation;
                }
            }

        }
    }

    void Awake()
    {
        //��������·����Ϊobject
        for (int i = 0; i < Buildings.Length; i++)
            Buildings[i].layer = LayerMask.NameToLayer("object");
        Roads[0].layer = LayerMask.NameToLayer("object");

        map = GetMap();
        maze_vitural = new GameObject[map.length, map.width];


        for (int i = 0; i < map.length; i++)
            for (int j = 0; j < map.width; j++)
            {
                if (map.maze[i, j] == "  " )
                {
                    var newB = Instantiate(Buildings[Random.Range(0, Buildings.Length)]);
                    buildings.Add(newB);
                    newB.transform.position = new Vector3(i, 0, j) * K;

                    // �������
                    newB.transform.Rotate(new Vector3(0, Random.Range(0, 4) * 90, 0));

                    newB.transform.SetParent(B);

                    /* �����б
                    newB.transform.Rotate(Vector3.forward, Random.Range(-4f, 4f));
                    */
                    buildingsLocation.Add(new Vector2Int(i, j));
                    Instantiate(Foundation, newB.transform.position, new Quaternion(), newB.transform);

                    maze_vitural[i, j] = newB;
                }
                else
                {
                    var newC = Instantiate(Roads[0]);
                    roads.Add(newC);
                    newC.transform.position = new Vector3(i, 0, j) * K;
                    newC.transform.SetParent(C);
                    //������������
                    roadsLocation.Add(new Vector2Int(i, j));
                    int[,] dic = new int[,] { { 0, 1 }, { -1, 0 }, { 0, -1 }, { 1, 0 } };
                    for (; x < 4; x++)//ȷ��������վ�����пյ�·��
                    { if (i + dic[x, 0] >= 0 && i + dic[x, 0] < map.length && j + dic[x, 1] >= 0 && j + dic[x, 1] < map.width && map.maze[i + dic[x, 0], j + dic[x, 1]]== "��")
                        { break; } }
                    Quaternion rotate = Quaternion.Euler(0, 90 * x, 0);
                    Vector3 direc = new Vector3((float)newC.transform.position[0], 0.1f, (float)newC.transform.position[2]);
                    Vector3 direc1 = new Vector3((float)newC.transform.position[0], 2f, (float)newC.transform.position[2]);
                    switch (map.maze[i, j])
                    {
                        case "��":
                            var busstop = Instantiate(Specials[0], direc, rotate, C);
                            Start_building = busstop;
                            break;
                        case "��":
                            var busstop1 = Instantiate(Specials[0], direc, rotate, C);
                            End_building = busstop1;
                            break;
                        case "��":
                            var monster = Instantiate(Monsters[0], direc1, rotate, newC.transform);
                            monstersLocation.Add(new Vector2Int(i, j));
                            Monsters11.Add(monster);
                            break;
                        case "͵":
                            var monster1 = Instantiate(Monsters[1], direc1, rotate, newC.transform);
                            monstersLocation.Add(new Vector2Int(i, j));
                            Monsters11.Add(monster1);
                            break;
                        case "å":
                            var monster2 = Instantiate(Monsters[2], direc1, rotate, newC.transform);
                            monstersLocation.Add(new Vector2Int(i, j));
                            Monsters11.Add(monster2);
                            break;
                        default: break;

                    }
                    maze_vitural[i, j] = newC;
                }
            }
        GenerateDecorations(map);

        Pl.di = new Vector2Int(map.start[0], map.start[1]);
        Pl_go.transform.position = new Vector3(Pl.di[0],0, Pl.di[1])*K;//��һ��ʼ�������λ����start��

    }
}
