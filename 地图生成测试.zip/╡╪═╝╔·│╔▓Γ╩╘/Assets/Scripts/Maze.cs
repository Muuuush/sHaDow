using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Maze
{
    public Player Pl;
    public int length;//��
    public int width;//��
    public string[,] maze;
    public string[,] maze_sight;
    private string[] blocks = { "��", "  ", "��", "��", "ʼ", "͵", "��", "å", "Ӱ", "��", "��", "��" };
    private string[] mst_normal = { "͵", "��", "å" };

    public int direction;//�Լ���ֵ ��Ϊһ������ͼ�ı��
    public int[] start;
    public int[] end;
    public List<List<Vector2Int>> sight_map_dic = new List<List<Vector2Int>>();//�ɼ���Χ�����


    //�������
    System.Random dice = new System.Random();//���� Next(x,y) ������y

    int xx()//��Ϊ��
    { return dice.Next(0, width); }
    int yy()//��
    { return dice.Next(0, length); }
    double GetDistance(int[] x, int[] y)
    { return (Math.Sqrt(Math.Pow(x[0] - y[0], 2) + Math.Pow(x[1] - y[1], 2))); }

    void GetSight()
    {
        for (int n = 1; n < 11; n++)
        {
            List<Vector2Int> sight_map = new List<Vector2Int>();
            if (n % 2 == 1)
            {
                for (int x = -n; x < n + 1; x++)
                    for (int y = -n; y < n + 1; y++)
                    { sight_map.Add(new Vector2Int(x, y)); }
            }
            else
            {
                for (int x = -n + 1; x < n; x++)
                    for (int y = -n + 1; y < n; y++)
                    { sight_map.Add(new Vector2Int(x, y)); }
                Vector2Int[] temp = { new Vector2Int(-n, 0), new Vector2Int(n, 0), new Vector2Int(0, n), new Vector2Int(0, -n) };
                sight_map.AddRange(temp);
            }
            sight_map_dic.Add(sight_map);//����ʱ��[sight-1]
        }
    }

    void GetMap_Sight()
    {

        maze_sight = new string[length, width];
        for (int y = 0; y < length; y++)
            for (int x = 0; x < width; x++)
            { maze_sight[y, x] = maze[y, x]; }

        int sight = Pl.sight;
        int sight_max = Pl.sight_max;


        List<Vector2Int> sight_map_now;
        if (sight_max >= sight)
        { sight_map_now = sight_map_dic[sight - 1]; }
        else
        { sight_map_now = sight_map_dic[sight_max - 1]; }

        for (int si = 0; si < sight_map_now.Count; si++)
        {
            int y = Pl.di[0] + sight_map_now[si][0];
            int x = Pl.di[1] + sight_map_now[si][1];
            if (0 <= y && y <= length - 1 && 0 <= x && x <= width - 1)
            { maze_sight[y, x] = "��"; }
        }
    }


    void AddBlankRandom(int nu)
    {
        for (int x = 0; x < nu; x++)
        {
            int[] di;
            do
            {
                di = new int[] { yy(), xx() };
            }
            while (maze[di[0], di[1]] != "��");
            maze[di[0], di[1]] = "  ";
        }
    }

    void update_shijian()
    {
        ArrayList qi = new ArrayList();
        ArrayList qi1 = new ArrayList();
        int[] x1;
        bool flag = false;
        for (int x = 0; x < 6; x++)
        {
            do
            {
                flag = false;
                x1 = new int[] { yy(), xx() };
                for (int y = 0; y < qi.Count; y++)
                {
                    int[] x2 = { (int)qi[y], (int)qi1[y] };
                    if (GetDistance(x2, x1) < 5)
                    { flag = true; }
                }
            }
            while (flag);
            maze[x1[0], x1[1]] = "��";
            qi.Add(x1[0]);
            qi1.Add(x1[1]);
        }
        int[] x4;
        for (int x3 = 0; x3 < 5; x3++)
        {
            x4 = new int[] { yy(), xx() };
            maze[x4[0], x4[1]] = "��";
        }
    }
    void update_monster(int nu)
    {
        for (int x = 0; x < nu; x++)
        {
            int[] x1;
            x1 = new int[] { yy(), xx() };
            while (maze[x1[0], x1[1]] != "��" || GetDistance(start, x1) < 5)
            { x1 = new int[] { yy(), xx() }; }
            var x2 = mst_normal[dice.Next(0, 2)];
            maze[x1[0], x1[1]] = x2;
        }
    }
    bool Deep()
    {
        string[,] map1 = new string[length + 2, width + 2];
        for (int y = 0; y < length + 2; y++)
            for (int x = 0; x < width + 2; x++)
            {
                if (y != 0 && y != length + 1 && x != 0 && x != width + 1)
                    map1[y, x] = maze[y - 1, x - 1];
                else
                    map1[y, x] = "11";

            }

        /*������û�г�����
        for (int y = 0; y < length+2; y++)
            for (int x = 0; x < width+2; x++)
            {
                if (x == width+1)
                { Console.WriteLine(map1[y, x]); }
                else
                { Console.Write(map1[y, x]); }
            }
        */


        ArrayList st = new ArrayList();
        ArrayList st1 = new ArrayList();
        string Open = "��";
        //string Close = "  ";����11
        string Passed = "��";
        int[,] dirs = { { 0, 1 }, { 1, 0 }, { 0, -1 }, { -1, 0 } };
        int[] start1 = new int[2];
        start.CopyTo(start1, 0);
        int[] end1 = new int[2];
        end.CopyTo(end1, 0);
        start1[0] += 1; start1[1] += 1;
        end1[0] += 1; end1[1] += 1;
        st.Add(start1); st1.Add(0);
        map1[start1[0], start1[1]] = Passed;
        while (st.Count > 0)
        {
            int[] pos = (int[])st[st.Count - 1];
            int nextd = (int)st1[st1.Count - 1];
            if (nextd == 4)
            {
                st.RemoveAt(st.Count - 1);
                st1.RemoveAt(st1.Count - 1);
            }
            while (nextd < 4)
            {
                int[] nextp = { pos[0] + dirs[nextd, 0], pos[1] + dirs[nextd, 1] };
                if (nextp.Equals(end1) || map1[end1[0], end1[1]].Equals(Passed))
                {
                    st.Add(end1);
                    st1.Add(0);
                    return true;
                }
                if (map1[nextp[0], nextp[1]].Equals(Open))//�����ַ�����Ҳ����������
                {
                    map1[nextp[0], nextp[1]] = Passed;
                    st.Add(nextp);
                    st1.Add(0);
                    break;
                }
                else
                {
                    nextd += 1;
                    st1[st1.Count - 1] = nextd;
                }
                if (nextd == 4)
                {
                    st.RemoveAt(st.Count - 1);
                    st1.RemoveAt(st1.Count - 1);
                    if (st.Count > 0)
                    {
                        st1[st1.Count - 1] = (int)st1[st1.Count - 1] + 1;
                    }
                }
            }
        }
        /*����û�г�����ʱ���õ�
        for (int y = 0; y < length + 2; y++)
            for (int x = 0; x < width + 2; x++)
            {
                if (x == width + 1)
                { Console.WriteLine(map1[y, x]); }
                else
                { Console.Write(map1[y, x]); }
            }
        */
        return false;
    }



    void born()//���õ�ͼ����յ�
    {
        do
        {
            do
            { start = new int[] { yy(), xx() }; }
            while (maze[start[0], start[1]] != "��");
            do
            { end = new int[] { yy(), xx() }; }
            while (maze[end[0], end[1]] != "��");
        }
        while (GetDistance(start, end) >= (Math.Pow(Math.Pow(width, 2) + Math.Pow(width, 2), 0.5) * 0.5) == false);// (width**2+length**2)**0.5*0.5

    }


    void Initial()
    {
        maze = new string[length, width];
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < length; y++)
            { maze[y, x] = "��"; }
        }
        int temp = (int)(length * width * 0.5);
        AddBlankRandom(dice.Next((int)(temp * 0.8), (int)(temp * 1.2)));
        born();
        update_monster(temp / 40 + 3);

    }
    void print()
    {
        for (int y = 0; y < length; y++)
            for (int x = 0; x < width; x++)
            {
                if (x == width - 1)
                { Console.WriteLine(maze[y, x]); }
                else
                { Console.Write(maze[y, x]); }
            }
    }
    public Maze(int di)
    {
        direction = di;
        length = dice.Next(30, 40);
        width = dice.Next(30, 40);
        do
        {
            Initial();
        }
        while (!Deep());
        update_shijian();
        maze[start[0], start[1]] = "��";
        maze[end[0], end[1]] = "��";
        print();
        //print();����������ӡ��ͼ
    }
}

